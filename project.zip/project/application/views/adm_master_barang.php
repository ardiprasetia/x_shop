<div class="container-fluid">
    <h2 class="mt-4">Data Barang</h2>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">&nbsp;</li>
    </ol>
    <div class="card mb-4">
        <div class="card-header"><i class="fas fa-table mr-1"></i>All Data Barang - 
            <a href="<?=base_url('adm_barang/barang_input');?>"> Input Data Barang 
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode</th>
                            <th>Nama Barang</th>
                            <th>Satuan</th>
                            <th>Volume</th>
                            <th>Merk</th>
                            <th>Jenis</th>
                            <th>Harga Barang</th>
                            <th>Stok</th>
                            <th>Status</th>
                            <th>&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                            $no = 0;
                            foreach($qr_barang->result() as $fd_barang){
                                $no++;
                    ?>
                        <tr>
                            <td><?=$no;?></td>
                            <td><?=$fd_barang->kode_barang;?></td>
                            <td><?=$fd_barang->nama;?></td>
                            <td><?=$fd_barang->satuan;?></td>
                            <td><?=$fd_barang->volume;?></td>
                            <td><?=$fd_barang->merk;?></td>
                            <td><?=$fd_barang->jenis;?></td>
                            <td><?=$fd_barang->harga;?></td>
                            <td><?=$fd_barang->stok;?></td>
                            <td><?=$fd_barang->status;?></td>
                            <td>Detail - Edit - Delete</td>
                        </tr>
                    <?php

                            }
                    ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>