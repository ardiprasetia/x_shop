<div class="container-fluid">
    <h2 class="mt-4">Data Barang
    </h2>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">&nbsp;</li>
    </ol>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table mr-1"></i>
            <a href="<?=base_url('adm_barang');?>">
            All Data Barang</a> -
        </div>
        <div class="card-body">
        <form  method='post' action="<?=base_url('adm_barang/barang_input_proses');?>">
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Kode Barang</label>
                    <div class="col-sm-3">
                    <input type="text" class="form-control" name="kode_barang">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Nama Barang</label>
                    <div class="col-sm-5">
                    <input type="text" class="form-control" name="nama">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Satuan</label>
                    <div class="col-sm-2">
                    <input type="text" class="form-control" name="satuan">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Volume</label>
                    <div class="col-sm-2">
                    <input type="number" class="form-control" name="volume">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Harga</label>
                    <div class="col-sm-3">
                    <input type="text" class="form-control" name="harga">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Merk</label>
                    <div class="col-sm-4">
                    <input type="text" class="form-control" name="merk">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Barcode</label>
                    <div class="col-sm-3">
                    <input type="text" class="form-control" name="barcode">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-2">Status</div>
                    <div class="col-sm-10">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="status">
                        <label class="form-check-label">
                        Aktif
                        </label>
                    </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Stok</label>
                    <div class="col-sm-3">
                    <input type="text" class="form-control" readonly placeholder="0" name="stok">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Jenis</label>
                    <div class="col-sm-4">
                    <input type="text" class="form-control" name="jenis">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="submit" class="btn btn-primary">Edit</button>
                    <button type="submit" class="btn btn-primary">Delete</button>
                    </div>
                </div>
        </form>
        
            
        </div>
    </div>
</div>