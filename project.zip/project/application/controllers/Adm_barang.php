<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Adm_barang extends CI_Controller {

	public function index()
	{
		parent::__construct();
		$this->db->select('*');
		$this->db->where('status', 'aktif');
		$send['qr_barang'] = $this->db->get('m_barang');

        $send['hal'] = 'adm_master_barang';
		$this->load->view('adm_v_home',$send);
    }
    public function barang_input()
    {
		$send['hal'] = 'adm_master_barang_input';
		$this->load->view('adm_v_home',$send);
	}
	public function barang_input_proses(){
		$data_barang = array(
			'kode_barang' => $this->input->post('kode_barang'),
			'nama' => $this->input->post('nama'),
			'satuan' => $this->input->post('satuan'),
			'volume' => $this->input->post('volume'),
			'harga' => $this->input->post('harga'),
			'merk' => $this->input->post('merk'),
			'barcode' => $this->input->post('barcode'),
			'status' => 'Aktif',
			'stok' => $this->input->post('stok'),
			'jenis' => $this->input->post('jenis')
		);
		$this->db->insert('m_barang',$data_barang);
		return redirect(base_url('adm_barang'));
	}
}
