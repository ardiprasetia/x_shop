-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 04 Sep 2020 pada 11.01
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tokoini`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `m_barang`
--

CREATE TABLE `m_barang` (
  `kode_barang` varchar(10) NOT NULL,
  `nama` char(60) NOT NULL,
  `satuan` char(15) NOT NULL,
  `volume` int(5) NOT NULL,
  `harga` int(20) NOT NULL,
  `merk` char(30) NOT NULL,
  `barcode` char(10) NOT NULL,
  `status` char(10) NOT NULL,
  `stok` int(10) NOT NULL,
  `jenis` char(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `m_barang`
--

INSERT INTO `m_barang` (`kode_barang`, `nama`, `satuan`, `volume`, `harga`, `merk`, `barcode`, `status`, `stok`, `jenis`) VALUES
('BRG2020001', 'AQUA', 'pcs', 12, 5000, 'AQUA INDO', '20200830', 'Aktif', 10, 'Minuman'),
('BRG2020002', 'Coca-Cola', 'pcs', 8, 12000, 'Coca-cola', '20200831', 'Aktif', 0, 'Minuman');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `m_barang`
--
ALTER TABLE `m_barang`
  ADD PRIMARY KEY (`kode_barang`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
